import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import mammoth from 'mammoth';
import * as xlsx from 'xlsx';
import JSZip from 'jszip';

dotenv.config();

const app = express();
const PORT = 3000;

// Increase body parsing limits to handle medium-to-large files (such as slide decks or PDFs)
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Initialize the Gemini SDK
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Custom PPTX Text Extractor
async function parsePptx(buffer: Buffer): Promise<string> {
  try {
    const zip = await JSZip.loadAsync(buffer);
    const slideFiles = Object.keys(zip.files).filter(name => 
      name.startsWith('ppt/slides/slide') && name.endsWith('.xml')
    );
    
    // Sort slide files numerically (e.g., slide1.xml, slide2.xml, slide10.xml)
    slideFiles.sort((a, b) => {
      const numA = parseInt(a.match(/\d+/)?. [0] || '0', 10);
      const numB = parseInt(b.match(/\d+/)?. [0] || '0', 10);
      return numA - numB;
    });

    let fullText = '';
    for (const slideFile of slideFiles) {
      const slideText = await zip.files[slideFile].async('string');
      // Matches the text container in PowerPoint XML schema
      const matches = slideText.match(/<a:t[^>]*>(.*?)<\/a:t>/g) || [];
      const extracted = matches
        .map(m => m.replace(/<[^>]+>/g, '') // remove XML tags
          .replace(/&amp;/g, '&')
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/&quot;/g, '"')
          .replace(/&apos;/g, "'")
          .trim()
        )
        .filter(Boolean);
      
      const slideNumber = slideFile.match(/\d+/)?. [0] || '0';
      if (extracted.length > 0) {
        fullText += `--- Slide ${slideNumber} ---\n` + extracted.join('\n') + '\n\n';
      }
    }
    return fullText || 'No text found in PowerPoint slides.';
  } catch (error: any) {
    console.error('PPTX parsing error:', error);
    throw new Error(`Failed to parse PowerPoint presentation: ${error.message}`);
  }
}

// Custom XLSX Spreadsheet Extractor
function parseXlsx(buffer: Buffer): string {
  try {
    const workbook = xlsx.read(buffer, { type: 'buffer' });
    let result = '';
    for (const sheetName of workbook.SheetNames) {
      const sheet = workbook.Sheets[sheetName];
      const csv = xlsx.utils.sheet_to_csv(sheet);
      if (csv.trim()) {
        result += `--- Sheet: ${sheetName} ---\n${csv}\n\n`;
      }
    }
    return result || 'No content found in spreadsheet.';
  } catch (error: any) {
    console.error('XLSX parsing error:', error);
    throw new Error(`Failed to parse spreadsheet: ${error.message}`);
  }
}

// Custom DOCX Word Extractor
async function parseDocx(buffer: Buffer): Promise<string> {
  try {
    const result = await mammoth.extractRawText({ buffer });
    return result.value || 'No text found in Word document.';
  } catch (error: any) {
    console.error('DOCX parsing error:', error);
    throw new Error(`Failed to parse Word document: ${error.message}`);
  }
}

// API Routes

// 1. File parsing route (XLSX, Word, PPTX, TXT)
app.post('/api/study/parse', async (req, res) => {
  const { fileName, fileType, base64Data } = req.body;
  if (!base64Data) {
    return res.status(400).json({ error: 'Missing file content base64Data.' });
  }

  try {
    const buffer = Buffer.from(base64Data, 'base64');
    let extractedText = '';

    if (fileType === 'docx') {
      extractedText = await parseDocx(buffer);
    } else if (fileType === 'pptx') {
      extractedText = await parsePptx(buffer);
    } else if (fileType === 'xlsx') {
      extractedText = parseXlsx(buffer);
    } else if (fileType === 'text') {
      extractedText = buffer.toString('utf-8');
    } else if (fileType === 'pdf') {
      // PDF can be uploaded directly as inlineData, but let's provide a notice
      extractedText = `[PDF Document: ${fileName}. Fully integrated with Gemini's visual processing engine.]`;
    } else if (fileType === 'image') {
      extractedText = `[Image Document: ${fileName}. Fully integrated with Gemini's visual OCR engine.]`;
    } else {
      extractedText = buffer.toString('utf-8');
    }

    res.json({ text: extractedText });
  } catch (error: any) {
    console.error('File parsing endpoint error:', error);
    res.status(500).json({ error: error.message || 'An error occurred while parsing the file.' });
  }
});

// 2. Document analysis route (provides key concepts, inconsistencies, missing info, suggested topics)
app.post('/api/study/analyze-material', async (req, res) => {
  const { fileName, fileType, textContent, base64Data } = req.body;

  try {
    // We will build a prompt to analyze this document
    let contents: any[] = [];
    let promptText = `Analyze the student's uploaded educational material named "${fileName}" (${fileType}).
Provide a deep structure analysis of this document.

You MUST return a JSON object with the following fields:
- "overview": a 2-3 sentence general summary of what the material is about.
- "keyConcepts": an array of objects, each with "name" and "description" (at least 5 key concepts/terms defined in the material).
- "inconsistencies": an array of strings representing any missing links, confusing descriptions, possible mistakes, or internal logical inconsistencies you found in this material. If none, return an empty array.
- "missingInfo": an array of strings representing key topics/background info related to this subject that are completely omitted or should be included to make the understanding complete.
- "suggestedTopics": an array of 3-4 related educational topics/fields suggested for future curious learning.

Material text content:
${textContent || ''}`;

    if ((fileType === 'pdf' || fileType === 'image') && base64Data) {
      contents.push({
        inlineData: {
          mimeType: fileType === 'pdf' ? 'application/pdf' : 'image/png',
          data: base64Data
        }
      });
      promptText += `\nNote: The full file binary has also been uploaded directly to your prompt context. Use it to verify visual notes, layouts, math formulas, or figures.`;
    }

    contents.push({ text: promptText });

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: contents,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overview: { type: Type.STRING },
            keyConcepts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING }
                },
                required: ['name', 'description']
              }
            },
            inconsistencies: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            missingInfo: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            suggestedTopics: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ['overview', 'keyConcepts', 'inconsistencies', 'missingInfo', 'suggestedTopics']
        }
      }
    });

    const report = JSON.parse(response.text?.trim() || '{}');
    res.json({ report });
  } catch (error: any) {
    console.error('Material analysis endpoint error:', error);
    res.status(500).json({ error: error.message || 'An error occurred during material analysis.' });
  }
});

// 3. AI Study Partner Tutor Chat Route
app.post('/api/study/chat', async (req, res) => {
  const { messages, activeMaterials, topic, difficulty } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Missing or invalid chat messages history.' });
  }

  try {
    // Construct active materials context
    let materialsTextContext = '';
    const inlineDataParts: any[] = [];

    if (activeMaterials && activeMaterials.length > 0) {
      materialsTextContext += `The student has activated these study materials for the current study session:\n`;
      activeMaterials.forEach((mat: any) => {
        materialsTextContext += `\n=== START OF MATERIAL: "${mat.name}" (${mat.type}) ===\n`;
        if (mat.parsedText) {
          materialsTextContext += mat.parsedText;
        }
        materialsTextContext += `\n=== END OF MATERIAL: "${mat.name}" ===\n`;

        // If PDF or Image, pass directly to Gemini as inline data for maximum native capability
        if (mat.base64Data && (mat.type === 'pdf' || mat.type === 'image')) {
          inlineDataParts.push({
            inlineData: {
              mimeType: mat.type === 'pdf' ? 'application/pdf' : (mat.mimeType || 'image/png'),
              data: mat.base64Data
            }
          });
        }
      });
    }

    const currentDifficultyStr = difficulty && difficulty !== 'none' 
      ? `Adapt explanations to the student's current understanding level: ${difficulty.toUpperCase()}`
      : 'Maintain an adaptive level (start concisely, offer Beginner/Intermediate/Advanced progressive depth).';

    const systemInstruction = `You are "Study Partner", a patient, supportive, and brilliant AI Educational Assistant and Personal Tutor.
Your ultimate goal is to ensure students genuinely understand academic and logical concepts, encourage critical thinking, and teach interactively.

Core Behaviors:
1. Prioritize education, science, mathematics, and logic across all fields. Answer general knowledge queries when requested.
2. If active study materials are provided, base your answers primarily on them using their definitions, terminology, formulas, and notations. Combine them with your vast academic knowledge for completeness. Point out inconsistencies, contradictions, or missing details in their materials clearly but supportively.
3. ADAPTIVE TUTORING PATTERN:
   - Start with a concise, crystal-clear, and simple first explanation.
   - Use real-world analogies, examples, and step-by-step reasoning (explaining the "why" of logical/numerical steps, highlighting common pitfalls, and sharing memory/mnemonics tricks).
   - AT THE END of every explanation, ask the student if they would like to go deeper or if they fully understand. Specifically mention they can ask for:
     * A "Beginner-level" explanation (extremely simple, visual, analogies).
     * An "Intermediate-level" explanation (more structured, details, concepts).
     * An "Advanced-level" explanation (technical rigor, mathematical proofs, formulas, code, or deep mechanics).
4. Interactive Engagement:
   - Do not assume the student understands after just one reply.
   - Suggest 2 related curiosity topics worth studying next.
   - Suggest 1 interactive practice question to test their understanding.
5. Search Grounding:
   - When answering questions that require up-to-date real-world facts or temporal knowledge, make sure your response integrates Google Search grounding results. Distinguish between verified facts and assumptions.
6. Format your output cleanly using markdown tables, bullet points, headers, and numbered steps. Keep equations neatly formatted.

Active Session Context:
Current Topic: ${topic || 'General learning'}
${currentDifficultyStr}

${materialsTextContext}`;

    // Map conversation messages to Gemini's history structure
    // We want to combine inlineDataParts of active files with the latest user query, or attach it to the context
    const apiMessages: any[] = [];
    
    // Convert history
    messages.forEach((m: any, idx: number) => {
      const isLast = idx === messages.length - 1;
      const role = m.sender === 'student' ? 'user' : 'model';
      
      const messageParts: any[] = [];
      
      if (role === 'user' && isLast) {
        // Embed files in the very last user message so the AI can use them to answer
        inlineDataParts.forEach(part => messageParts.push(part));
        messageParts.push({ text: m.text });
      } else {
        messageParts.push({ text: m.text });
      }

      apiMessages.push({
        role: role,
        parts: messageParts
      });
    });

    // Generate content using Gemini 3.5-flash
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: apiMessages,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
        tools: [{ googleSearch: {} }] // Enable real-time Google search grounding!
      }
    });

    // Extract citations from grounding metadata if present
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const citations = chunks?.map((chunk: any) => ({
      title: chunk.web?.title || 'Web Search Source',
      url: chunk.web?.uri || ''
    })).filter((c: any) => c.url) || [];

    // Parse the response to suggest follow-up questions
    // Since we want follow-up questions to be interactive buttons, let's extract them if possible or generate them dynamically,
    // or let's write a quick separate prompt if needed, but it's simpler to just let the model output them in markdown.
    // However, to make it super premium, let's extract suggested questions by parsing the markdown or regex, or we can just ask the AI to append suggestions that we can extract or render nicely.
    
    res.json({
      text: response.text,
      citations: citations,
    });
  } catch (error: any) {
    console.error('Tutor chat endpoint error:', error);
    res.status(500).json({ error: error.message || 'An error occurred during tutoring session.' });
  }
});

// 4. Study Toolkit Generator Route (Summaries, Flashcards, Quizzes, roadmaps, comparison tables, etc.)
app.post('/api/study/generate-tool', async (req, res) => {
  const { toolType, topic, activeMaterials, additionalInstructions } = req.body;

  try {
    let materialsTextContext = '';
    if (activeMaterials && activeMaterials.length > 0) {
      materialsTextContext += `The student has active study materials:\n`;
      activeMaterials.forEach((mat: any) => {
        materialsTextContext += `\n=== MATERIAL: "${mat.name}" ===\n${mat.parsedText || ''}\n`;
      });
    }

    let systemPrompt = `You are a specialized educational content generator. Your job is to output perfectly structured JSON for students study features based on the topic and active materials.
Return ONLY valid JSON. No surrounding markdown, no backticks, no comments. Just pure JSON.

Topic/Subject: ${topic}
${materialsTextContext}
Additional Instructions: ${additionalInstructions || 'None'}`;

    let responseSchema: any = {};

    if (toolType === 'flashcards') {
      systemPrompt += `\nGenerate 8 highly effective interactive study flashcards. Focus on key terms, definitions, and core formulas. Each flashcard must include a question, a definitive answer, and a helpful conceptual hint.`;
      responseSchema = {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING, description: "A unique short string ID (e.g. fc-1, fc-2)" },
            question: { type: Type.STRING },
            answer: { type: Type.STRING },
            hint: { type: Type.STRING, description: "A quick clue or mnemonic to help recall" }
          },
          required: ['id', 'question', 'answer', 'hint']
        }
      };
    } else if (toolType === 'quiz') {
      systemPrompt += `\nGenerate a professional 5-question mock exam or interactive quiz. Include a mix of multiple choice questions.
For numerical or logical questions, show step-by-step reasoning solutions in the "steps" array. Always explain why the correct answer is right and why other options are common pitfalls in the "explanation" field.`;
      responseSchema = {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "Must contain exactly 4 options"
            },
            correctAnswerIndex: { type: Type.INTEGER, description: "0-indexed index of the correct option (0 to 3)" },
            explanation: { type: Type.STRING, description: "Comprehensive explanation of correct concept vs pitfalls" },
            steps: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Optional array of logical steps to solve, especially for math, CS, science, or commerce"
            }
          },
          required: ['question', 'options', 'correctAnswerIndex', 'explanation']
        }
      };
    } else if (toolType === 'presentation') {
      systemPrompt += `\nGenerate a structured slide presentation deck with 5-6 slides.
Layout must be one of: 'intro', 'content', 'comparison', 'conclusion'.
Each slide has a title, 3-4 concise educational bullet points, and a comprehensive summary script for speech.`;
      responseSchema = {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            bulletPoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            layout: { 
              type: Type.STRING, 
              description: "Must be one of 'intro', 'content', 'comparison', 'conclusion'" 
            },
            summary: { type: Type.STRING, description: "A narrative paragraph explaining this slide's concept to a listener" }
          },
          required: ['title', 'bulletPoints', 'layout', 'summary']
        }
      };
    } else if (toolType === 'roadmap') {
      systemPrompt += `\nGenerate a step-by-step study guide and custom roadmap consisting of 4-5 core stages to master this topic. Provide stages, descriptions, list of key concepts, and high-quality recommended learning resources.`;
      responseSchema = {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            stage: { type: Type.STRING, description: "Stage title (e.g. Stage 1: Foundations)" },
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            keyConcepts: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            recommendedResources: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ['stage', 'title', 'description', 'keyConcepts', 'recommendedResources']
        }
      };
    } else if (toolType === 'notes') {
      systemPrompt += `\nGenerate well-formatted PDF revision notes. Break the topic down into 3-4 structured headings, with deep explanatory paragraphs, definitions, and an executive cheat-sheet summary section.`;
      responseSchema = {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          sections: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                heading: { type: Type.STRING },
                content: { type: Type.STRING },
              },
              required: ['heading', 'content']
            }
          },
          cheatSheet: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ['title', 'sections', 'cheatSheet']
      };
    } else if (toolType === 'comparison') {
      systemPrompt += `\nGenerate a concept comparison table contrasting 2 or 3 distinct sub-concepts, models, or paradigms in this field. Each row compares a single dimension or attribute.`;
      responseSchema = {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          headers: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "First header is always 'Dimension' or 'Attribute', followed by the concept names (e.g. ['Dimension', 'SQL', 'NoSQL'])"
          },
          rows: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                concept: { type: Type.STRING, description: "The attribute/dimension being compared (e.g. Scalability)" },
                values: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Contrast values for each concept matching the header order"
                }
              },
              required: ['concept', 'values']
            }
          }
        },
        required: ['title', 'headers', 'rows']
      };
    } else if (toolType === 'formulas') {
      systemPrompt += `\nGenerate a custom formula and cheat sheet. Provide formulas, math/logical equations, variables explained, and real-world application examples.`;
      responseSchema = {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          formulas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                equation: { type: Type.STRING },
                variables: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "List of variables explained (e.g. 'm = mass in kg')"
                },
                application: { type: Type.STRING, description: "A neat numerical/logical example calculation" }
              },
              required: ['name', 'equation', 'variables', 'application']
            }
          }
        },
        required: ['title', 'formulas']
      };
    } else if (toolType === 'mindmap') {
      systemPrompt += `\nGenerate an interactive Concept Map and Mind Map consisting of concepts connected by logical relationships.
Return nodes (id, label, type) and links (source, target, relationship). Type can be 'main' (central topic), 'sub' (sub-topic), or 'detail' (deep facts). Ensure there are at least 8 nodes and links connecting them clearly.`;
      responseSchema = {
        type: Type.OBJECT,
        properties: {
          nodes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                label: { type: Type.STRING },
                type: { type: Type.STRING, description: "Must be 'main', 'sub', or 'detail'" }
              },
              required: ['id', 'label', 'type']
            }
          },
          links: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                source: { type: Type.STRING, description: "ID of source node" },
                target: { type: Type.STRING, description: "ID of target node" },
                relationship: { type: Type.STRING, description: "Action/relationship linking them (e.g. 'defines', 'requires', 'implements')" }
              },
              required: ['source', 'target', 'relationship']
            }
          }
        },
        required: ['nodes', 'links']
      };
    } else {
      // Default to summary / notes
      systemPrompt += `\nGenerate a comprehensive summary structured as multiple logical headings and paragraphs.`;
      responseSchema = {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          sections: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                heading: { type: Type.STRING },
                content: { type: Type.STRING }
              },
              required: ['heading', 'content']
            }
          },
          cheatSheet: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ['title', 'sections', 'cheatSheet']
      };
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: systemPrompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
        temperature: 0.2 // Lower temperature for high schema compliance
      }
    });

    const outputData = JSON.parse(response.text?.trim() || '{}');
    res.json(outputData);
  } catch (error: any) {
    console.error('Toolkit generator endpoint error:', error);
    res.status(500).json({ error: error.message || 'An error occurred during toolkit generation.' });
  }
});

// Serve frontend assets
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Study Partner backend server running on http://localhost:${PORT}`);
  });
}

startServer();
