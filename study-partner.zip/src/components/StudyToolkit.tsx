import React, { useState } from 'react';
import { 
  Sparkles, 
  BookOpen, 
  Presentation, 
  HelpCircle, 
  Compass, 
  Flame, 
  Table, 
  FileText, 
  Brain, 
  ArrowLeft, 
  ArrowRight, 
  RotateCw, 
  Check, 
  X, 
  Printer, 
  Play, 
  Activity,
  AlertCircle
} from 'lucide-react';
import { 
  StudyMaterial, 
  Flashcard, 
  QuizQuestion, 
  PresentationSlide, 
  StudyNotes, 
  ConceptMap, 
  RoadmapStep, 
  ComparisonTable, 
  FormulaSheet 
} from '../types';

interface StudyToolkitProps {
  activeMaterials: StudyMaterial[];
  currentTopic: string;
}

type ToolType = 'notes' | 'presentation' | 'flashcards' | 'quiz' | 'roadmap' | 'comparison' | 'formulas' | 'mindmap';

export default function StudyToolkit({ activeMaterials, currentTopic }: StudyToolkitProps) {
  const [activeTool, setActiveTool] = useState<ToolType>('notes');
  const [topicInput, setTopicInput] = useState(currentTopic || 'Photosynthesis');
  const [isGenerating, setIsGenerating] = useState(false);
  const [additionalInstructions, setAdditionalInstructions] = useState('');

  // Generated results
  const [generatedNotes, setGeneratedNotes] = useState<StudyNotes | null>(null);
  const [generatedSlides, setGeneratedSlides] = useState<PresentationSlide[] | null>(null);
  const [generatedFlashcards, setGeneratedFlashcards] = useState<Flashcard[] | null>(null);
  const [generatedQuiz, setGeneratedQuiz] = useState<QuizQuestion[] | null>(null);
  const [generatedRoadmap, setGeneratedRoadmap] = useState<RoadmapStep[] | null>(null);
  const [generatedComparison, setGeneratedComparison] = useState<ComparisonTable | null>(null);
  const [generatedFormulas, setGeneratedFormulas] = useState<FormulaSheet | null>(null);
  const [generatedMindmap, setGeneratedMindmap] = useState<ConceptMap | null>(null);

  // UI state for tools
  const [activeSlideIdx, setActiveSlideIdx] = useState(0);
  const [showSlideScript, setShowSlideScript] = useState(false);
  const [activeFlashcardIdx, setActiveFlashcardIdx] = useState(0);
  const [isFlashcardFlipped, setIsFlashcardFlipped] = useState(false);
  const [showFlashcardHint, setShowFlashcardHint] = useState(false);
  const [cardStats, setCardStats] = useState({ known: 0, review: 0 });

  // Quiz active state
  const [activeQuestionIdx, setActiveQuestionIdx] = useState(0);
  const [selectedQuizAnswer, setSelectedQuizAnswer] = useState<number | null>(null);
  const [isQuizSubmitted, setIsQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const [showQuizSteps, setShowQuizSteps] = useState(false);

  // SVG Concept Map state
  const [hoveredConceptNode, setHoveredConceptNode] = useState<string | null>(null);

  // Fetch / Generate requested study tool
  const generateToolData = async (type: ToolType) => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/study/generate-tool', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolType: type,
          topic: topicInput,
          activeMaterials: activeMaterials,
          additionalInstructions: additionalInstructions
        })
      });

      if (!response.ok) {
        throw new Error('Failed to generate tool data.');
      }

      const data = await response.json();

      // Reset and save specific tool state
      if (type === 'notes') setGeneratedNotes(data);
      else if (type === 'presentation') {
        setGeneratedSlides(data);
        setActiveSlideIdx(0);
        setShowSlideScript(false);
      } else if (type === 'flashcards') {
        setGeneratedFlashcards(data);
        setActiveFlashcardIdx(0);
        setIsFlashcardFlipped(false);
        setShowFlashcardHint(false);
        setCardStats({ known: 0, review: 0 });
      } else if (type === 'quiz') {
        setGeneratedQuiz(data);
        setActiveQuestionIdx(0);
        setSelectedQuizAnswer(null);
        setIsQuizSubmitted(false);
        setQuizScore(0);
        setShowQuizSteps(false);
      } else if (type === 'roadmap') setGeneratedRoadmap(data);
      else if (type === 'comparison') setGeneratedComparison(data);
      else if (type === 'formulas') setGeneratedFormulas(data);
      else if (type === 'mindmap') {
        setGeneratedMindmap(data);
        setHoveredConceptNode(null);
      }

    } catch (err: any) {
      console.error(err);
      alert(`Generation failed: ${err.message || 'Unknown error'}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Printable styles for Revision Notes
  const handlePrintNotes = () => {
    window.print();
  };

  // Node position helper for radial SVG Mindmap
  const getMindmapCoords = (index: number, total: number) => {
    const width = 600;
    const height = 400;
    const centerX = width / 2;
    const centerY = height / 2;
    
    if (index === 0) return { x: centerX, y: centerY }; // Central Node
    
    // Distribute remaining nodes radially
    const angle = (2 * Math.PI * (index - 1)) / (total - 1);
    const radius = 140;
    return {
      x: centerX + radius * Math.cos(angle),
      y: centerY + radius * Math.sin(angle)
    };
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/40 border border-slate-800 rounded-2xl overflow-hidden">
      {/* Toolkit Toolbar */}
      <div className="p-4 bg-slate-900 border-b border-slate-800">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-4">
            <label className="block text-[10px] text-slate-400 font-semibold tracking-wide uppercase mb-1">
              Study Topic / Context:
            </label>
            <input
              type="text"
              value={topicInput}
              onChange={(e) => setTopicInput(e.target.value)}
              placeholder="e.g. Mitochondria, Supply and Demand, Rust Lang"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all font-sans"
            />
          </div>
          
          <div className="md:col-span-5">
            <label className="block text-[10px] text-slate-400 font-semibold tracking-wide uppercase mb-1">
              Additional Directives (Optional):
            </label>
            <input
              type="text"
              value={additionalInstructions}
              onChange={(e) => setAdditionalInstructions(e.target.value)}
              placeholder="e.g. Focus on calculations, keep notes short"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all font-sans"
            />
          </div>

          <div className="md:col-span-3 flex items-end">
            <button
              onClick={() => generateToolData(activeTool)}
              disabled={isGenerating || !topicInput.trim()}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-medium text-xs rounded-xl py-2.5 px-4 transition-all flex items-center justify-center gap-1.5 shadow-md shadow-indigo-950/20"
            >
              <Sparkles className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
              <span>{isGenerating ? 'Formulating...' : `Generate ${activeTool.toUpperCase()}`}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Toolkit Feature Selector Tab Bar */}
      <div className="flex border-b border-slate-800 bg-slate-950/40 overflow-x-auto">
        {[
          { id: 'notes', label: 'Study Notes', icon: FileText },
          { id: 'presentation', label: 'Presentation Slides', icon: Presentation },
          { id: 'flashcards', label: 'Flashcards', icon: Compass },
          { id: 'quiz', label: 'Mock Test', icon: HelpCircle },
          { id: 'roadmap', label: 'Learning Roadmap', icon: Flame },
          { id: 'comparison', label: 'Comparison Grid', icon: Table },
          { id: 'formulas', label: 'Formula Sheet', icon: BookOpen },
          { id: 'mindmap', label: 'Concept Mindmap', icon: Brain },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTool === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTool(tab.id as ToolType)}
              className={`flex items-center gap-2 py-3 px-4.5 border-b-2 text-xs font-semibold whitespace-nowrap transition-all ${
                isActive 
                  ? 'border-indigo-500 text-indigo-400 bg-slate-900/30' 
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Generated Content Rendering Space */}
      <div className="flex-1 p-6 overflow-y-auto bg-slate-950/15 print:bg-white print:text-black">
        {isGenerating ? (
          <div className="h-64 flex flex-col items-center justify-center text-center">
            <div className="p-4 bg-indigo-950/30 rounded-2xl border border-indigo-900/40 relative mb-4">
              <Sparkles className="w-8 h-8 text-indigo-400 animate-pulse" />
              <div className="absolute inset-0 border border-indigo-500 rounded-2xl animate-ping opacity-25"></div>
            </div>
            <h4 className="font-semibold text-slate-200 text-sm">Study Partner is thinking...</h4>
            <p className="text-xs text-slate-400 max-w-sm mt-1.5 leading-relaxed">
              We are scanning academic concepts and compiling beautiful educational layouts. This takes just a moment!
            </p>
          </div>
        ) : (
          <div className="h-full">
            {/* 1. PDF Study Notes */}
            {activeTool === 'notes' && (
              <div className="h-full">
                {generatedNotes ? (
                  <div className="max-w-3xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 shadow-xl print:shadow-none print:border-none print:p-0 print:bg-white">
                    <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800 print:border-slate-300">
                      <div>
                        <span className="text-[10px] font-mono text-indigo-400 font-bold uppercase print:hidden">REVISION NOTES</span>
                        <h2 className="text-2xl font-bold font-display text-slate-100 print:text-black">{generatedNotes.title}</h2>
                      </div>
                      <button
                        onClick={handlePrintNotes}
                        className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold border border-slate-700 flex items-center gap-1.5 transition-all print:hidden"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print or Save PDF</span>
                      </button>
                    </div>

                    <div className="space-y-6 print:text-black">
                      {generatedNotes.sections.map((sec, i) => (
                        <div key={i} className="prose prose-invert max-w-none print:prose-none">
                          <h3 className="text-lg font-bold text-slate-200 mt-2 mb-2 pb-1 border-b border-slate-850 print:text-black print:border-slate-200">
                            {sec.heading}
                          </h3>
                          <p className="text-sm text-slate-300 leading-relaxed font-sans font-normal whitespace-pre-wrap print:text-black">
                            {sec.content}
                          </p>
                        </div>
                      ))}

                      {/* Cheatsheet section */}
                      <div className="mt-8 p-5 bg-indigo-950/20 border border-indigo-900/40 rounded-xl print:bg-slate-100 print:border-slate-300 print:text-black">
                        <h4 className="text-xs font-bold font-mono tracking-wider uppercase text-indigo-400 print:text-black mb-3">
                          Quick Revision Cheat Sheet
                        </h4>
                        <ul className="space-y-2">
                          {generatedNotes.cheatSheet.map((item, idx) => (
                            <li key={idx} className="flex gap-2.5 text-xs text-slate-300 items-start print:text-black">
                              <span className="text-indigo-400 font-bold print:text-black">•</span>
                              <p>{item}</p>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="h-64 flex flex-col items-center justify-center text-slate-500">
                    <FileText className="w-12 h-12 stroke-1 mb-2.5" />
                    <p className="text-sm font-medium">No Study Notes generated yet</p>
                    <p className="text-xs text-slate-500 mt-0.5">Click the "Generate Notes" button at the top to draft textbook revision material.</p>
                  </div>
                )}
              </div>
            )}

            {/* 2. PPT Presentation Slides */}
            {activeTool === 'presentation' && (
              <div className="h-full max-w-4xl mx-auto">
                {generatedSlides ? (
                  <div className="space-y-6">
                    {/* Interactive Slide Canvas */}
                    <div className="aspect-[16/9] w-full rounded-2xl border border-slate-800 bg-slate-950 relative flex flex-col p-8 md:p-12 overflow-hidden shadow-2xl justify-between group">
                      
                      {/* Interactive Presentation Accent Background glows based on layout */}
                      <div className={`absolute top-0 right-0 w-80 h-80 rounded-full blur-[120px] opacity-25 transition-all duration-700 ${
                        generatedSlides[activeSlideIdx].layout === 'intro' ? 'bg-indigo-600' :
                        generatedSlides[activeSlideIdx].layout === 'comparison' ? 'bg-amber-600' :
                        generatedSlides[activeSlideIdx].layout === 'conclusion' ? 'bg-emerald-600' : 'bg-slate-600'
                      }`}></div>

                      {/* Slide Header Indicator */}
                      <div className="flex justify-between items-center z-10">
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-500">
                          {generatedSlides[activeSlideIdx].layout.toUpperCase()} SLIDE
                        </span>
                        <span className="text-xs text-slate-400 font-mono font-semibold">
                          {activeSlideIdx + 1} / {generatedSlides.length}
                        </span>
                      </div>

                      {/* Slide Core Content */}
                      <div className="flex-1 flex flex-col justify-center my-6 z-10">
                        {generatedSlides[activeSlideIdx].layout === 'intro' ? (
                          <div className="text-center space-y-4">
                            <h2 className="text-3xl md:text-5xl font-extrabold font-display tracking-tight text-white leading-tight">
                              {generatedSlides[activeSlideIdx].title}
                            </h2>
                            <div className="w-16 h-1 bg-indigo-500 mx-auto rounded-full"></div>
                            <div className="space-y-1 text-slate-400 text-xs md:text-sm">
                              {generatedSlides[activeSlideIdx].bulletPoints.map((bp, index) => (
                                <p key={index}>{bp}</p>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <h2 className="text-2xl md:text-4xl font-bold font-display text-white tracking-tight">
                              {generatedSlides[activeSlideIdx].title}
                            </h2>
                            <ul className="space-y-3 md:space-y-4">
                              {generatedSlides[activeSlideIdx].bulletPoints.map((bp, index) => (
                                <li key={index} className="flex gap-3 items-start text-sm md:text-base text-slate-300">
                                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-2.5 flex-shrink-0"></span>
                                  <p>{bp}</p>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>

                      {/* Slide Footer Navigation */}
                      <div className="flex items-center justify-between border-t border-slate-900/50 pt-4 z-10">
                        <button
                          onClick={() => setActiveSlideIdx(prev => Math.max(0, prev - 1))}
                          disabled={activeSlideIdx === 0}
                          className="p-2 text-slate-400 hover:text-white hover:bg-slate-900 disabled:opacity-40 rounded-lg transition-all"
                        >
                          <ArrowLeft className="w-5 h-5" />
                        </button>

                        {/* Progress Indicators */}
                        <div className="flex gap-1.5">
                          {generatedSlides.map((_, idx) => (
                            <span 
                              key={idx}
                              onClick={() => setActiveSlideIdx(idx)}
                              className={`w-5 h-1.5 rounded-full cursor-pointer transition-all ${
                                activeSlideIdx === idx ? 'bg-indigo-500' : 'bg-slate-800 hover:bg-slate-700'
                              }`}
                            ></span>
                          ))}
                        </div>

                        <button
                          onClick={() => setActiveSlideIdx(prev => Math.min(generatedSlides.length - 1, prev + 1))}
                          disabled={activeSlideIdx === generatedSlides.length - 1}
                          className="p-2 text-slate-400 hover:text-white hover:bg-slate-900 disabled:opacity-40 rounded-lg transition-all"
                        >
                          <ArrowRight className="w-5 h-5" />
                        </button>
                      </div>
                    </div>

                    {/* Speech / Speaker notes script */}
                    <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-lg">
                      <div className="flex justify-between items-center mb-3">
                        <h4 className="text-xs font-bold font-mono tracking-wider uppercase text-indigo-400 flex items-center gap-1.5">
                          <Presentation className="w-4 h-4" />
                          Presentation Speaker Script
                        </h4>
                        <button
                          onClick={() => setShowSlideScript(!showSlideScript)}
                          className="text-xs text-slate-400 hover:text-white font-medium bg-slate-800 px-3 py-1 rounded-lg"
                        >
                          {showSlideScript ? 'Hide Script' : 'Show Script'}
                        </button>
                      </div>
                      
                      {showSlideScript && (
                        <p className="text-xs text-slate-300 leading-relaxed font-sans whitespace-pre-wrap bg-slate-950/40 p-4 rounded-xl border border-slate-900">
                          {generatedSlides[activeSlideIdx].summary}
                        </p>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="h-64 flex flex-col items-center justify-center text-slate-500">
                    <Presentation className="w-12 h-12 stroke-1 mb-2.5" />
                    <p className="text-sm font-medium">No Presentation Slides generated yet</p>
                    <p className="text-xs text-slate-500 mt-0.5">Click the "Generate Presentation" button to format structured lecture slide decks.</p>
                  </div>
                )}
              </div>
            )}

            {/* 3. Interactive Flashcards */}
            {activeTool === 'flashcards' && (
              <div className="h-full max-w-2xl mx-auto">
                {generatedFlashcards ? (
                  <div className="space-y-6">
                    {/* Progress tracking */}
                    <div className="flex justify-between items-center text-xs text-slate-400">
                      <span>Card {activeFlashcardIdx + 1} of {generatedFlashcards.length}</span>
                      <div className="flex items-center gap-4">
                        <span className="text-emerald-400">Known: {cardStats.known}</span>
                        <span className="text-rose-400">Review: {cardStats.review}</span>
                      </div>
                    </div>

                    {/* Main Flashcard Container with Flip Animation */}
                    <div 
                      onClick={() => setIsFlashcardFlipped(!isFlashcardFlipped)}
                      className="aspect-[3/2] w-full relative perspective-1000 cursor-pointer h-72 md:h-80"
                    >
                      <div className={`w-full h-full duration-500 transform-style-3d relative ${
                        isFlashcardFlipped ? 'rotate-y-180' : ''
                      }`}>
                        {/* Front of Card */}
                        <div className="absolute inset-0 bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 flex flex-col justify-between backface-hidden shadow-2xl">
                          <div className="flex justify-between items-center text-[10px] text-slate-500 font-semibold font-mono">
                            <span>QUESTION SIDE</span>
                            <Sparkles className="w-4 h-4 text-indigo-400/70" />
                          </div>
                          
                          <div className="text-center py-4">
                            <h3 className="text-lg md:text-2xl font-bold text-slate-100 font-display">
                              {generatedFlashcards[activeFlashcardIdx].question}
                            </h3>
                          </div>

                          <div className="text-center text-xs text-slate-500 font-mono">
                            <span>Click to Flip Card</span>
                          </div>
                        </div>

                        {/* Back of Card */}
                        <div className="absolute inset-0 bg-indigo-950/40 border border-indigo-500/30 rounded-2xl p-6 md:p-8 flex flex-col justify-between backface-hidden rotate-y-180 shadow-2xl">
                          <div className="flex justify-between items-center text-[10px] text-indigo-400 font-semibold font-mono">
                            <span>ANSWER SIDE</span>
                            <Check className="w-4 h-4 text-indigo-400" />
                          </div>

                          <div className="text-center py-4">
                            <p className="text-sm md:text-lg text-slate-200 leading-relaxed">
                              {generatedFlashcards[activeFlashcardIdx].answer}
                            </p>
                          </div>

                          <div className="text-center text-xs text-slate-500 font-mono">
                            <span>Click to flip back</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Card Helpers and Nav controls */}
                    <div className="flex flex-col gap-4">
                      <div className="flex justify-between items-center">
                        {/* Hint panel */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowFlashcardHint(!showFlashcardHint);
                          }}
                          className="text-xs text-indigo-300 hover:text-indigo-200 bg-indigo-950/30 px-3 py-1.5 rounded-lg border border-indigo-900/30 transition-all font-medium"
                        >
                          {showFlashcardHint ? 'Hide Clue' : 'Reveal Clue'}
                        </button>

                        <div className="flex gap-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setCardStats(prev => ({ ...prev, review: prev.review + 1 }));
                              if (activeFlashcardIdx < generatedFlashcards.length - 1) {
                                setActiveFlashcardIdx(prev => prev + 1);
                                setIsFlashcardFlipped(false);
                                setShowFlashcardHint(false);
                              }
                            }}
                            className="bg-rose-950/40 text-rose-300 text-xs px-3.5 py-1.5 rounded-lg border border-rose-900/30 font-medium hover:bg-rose-950/60 transition-all"
                          >
                            Need Practice
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setCardStats(prev => ({ ...prev, known: prev.known + 1 }));
                              if (activeFlashcardIdx < generatedFlashcards.length - 1) {
                                setActiveFlashcardIdx(prev => prev + 1);
                                setIsFlashcardFlipped(false);
                                setShowFlashcardHint(false);
                              }
                            }}
                            className="bg-emerald-950/40 text-emerald-300 text-xs px-3.5 py-1.5 rounded-lg border border-emerald-900/30 font-medium hover:bg-emerald-950/60 transition-all"
                          >
                            I Know It!
                          </button>
                        </div>
                      </div>

                      {showFlashcardHint && (
                        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-400 leading-relaxed font-sans">
                          💡 <span className="font-semibold text-slate-300">Memory Trigger:</span> {generatedFlashcards[activeFlashcardIdx].hint}
                        </div>
                      )}

                      {/* Main Navigation Row */}
                      <div className="flex justify-between mt-4">
                        <button
                          onClick={() => {
                            setActiveFlashcardIdx(prev => Math.max(0, prev - 1));
                            setIsFlashcardFlipped(false);
                            setShowFlashcardHint(false);
                          }}
                          disabled={activeFlashcardIdx === 0}
                          className="p-2 text-slate-400 hover:text-white disabled:opacity-40"
                        >
                          <ArrowLeft className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => {
                            setActiveFlashcardIdx(0);
                            setIsFlashcardFlipped(false);
                            setShowFlashcardHint(false);
                            setCardStats({ known: 0, review: 0 });
                          }}
                          className="text-xs text-slate-500 hover:text-slate-300 flex items-center gap-1"
                        >
                          <RotateCw className="w-3.5 h-3.5" />
                          <span>Restart Deck</span>
                        </button>
                        <button
                          onClick={() => {
                            setActiveFlashcardIdx(prev => Math.min(generatedFlashcards.length - 1, prev + 1));
                            setIsFlashcardFlipped(false);
                            setShowFlashcardHint(false);
                          }}
                          disabled={activeFlashcardIdx === generatedFlashcards.length - 1}
                          className="p-2 text-slate-400 hover:text-white disabled:opacity-40"
                        >
                          <ArrowRight className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="h-64 flex flex-col items-center justify-center text-slate-500">
                    <Compass className="w-12 h-12 stroke-1 mb-2.5" />
                    <p className="text-sm font-medium">No Flashcards generated yet</p>
                    <p className="text-xs text-slate-500 mt-0.5">Click the "Generate Flashcards" button to craft micro study aids.</p>
                  </div>
                )}
              </div>
            )}

            {/* 4. Practice Quizzes & Mock Exams */}
            {activeTool === 'quiz' && (
              <div className="h-full max-w-2xl mx-auto">
                {generatedQuiz ? (
                  <div className="space-y-6">
                    {/* Header */}
                    <div className="flex justify-between items-center text-xs text-slate-400">
                      <span>Question {activeQuestionIdx + 1} of {generatedQuiz.length}</span>
                      <span>Current Score: {quizScore} / {generatedQuiz.length}</span>
                    </div>

                    {/* Question Card */}
                    <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl shadow-xl">
                      <h3 className="text-sm md:text-base font-semibold text-slate-100 mb-5 leading-relaxed font-display">
                        {generatedQuiz[activeQuestionIdx].question}
                      </h3>

                      {/* Options */}
                      <div className="space-y-2.5">
                        {generatedQuiz[activeQuestionIdx].options.map((option, idx) => {
                          const isSelected = selectedQuizAnswer === idx;
                          const isCorrect = generatedQuiz[activeQuestionIdx].correctAnswerIndex === idx;
                          
                          let btnStyle = 'bg-slate-950 border-slate-850 hover:border-slate-700 text-slate-300';
                          
                          if (isQuizSubmitted) {
                            if (isCorrect) {
                              btnStyle = 'bg-emerald-950/20 border-emerald-500 text-emerald-300';
                            } else if (isSelected) {
                              btnStyle = 'bg-rose-950/20 border-rose-500 text-rose-300';
                            } else {
                              btnStyle = 'bg-slate-950/30 border-slate-900/60 text-slate-500';
                            }
                          } else if (isSelected) {
                            btnStyle = 'bg-indigo-950/40 border-indigo-500 text-indigo-300';
                          }

                          return (
                            <button
                              key={idx}
                              onClick={() => !isQuizSubmitted && setSelectedQuizAnswer(idx)}
                              disabled={isQuizSubmitted}
                              className={`w-full text-left p-3.5 rounded-xl border text-xs md:text-sm transition-all duration-200 font-medium flex items-center justify-between ${btnStyle}`}
                            >
                              <span>{option}</span>
                              {isQuizSubmitted && isCorrect && <Check className="w-4 h-4 text-emerald-400" />}
                              {isQuizSubmitted && isSelected && !isCorrect && <X className="w-4 h-4 text-rose-400" />}
                            </button>
                          );
                        })}
                      </div>

                      {/* Action trigger */}
                      {!isQuizSubmitted ? (
                        <button
                          onClick={() => {
                            if (selectedQuizAnswer === null) return;
                            setIsQuizSubmitted(true);
                            if (selectedQuizAnswer === generatedQuiz[activeQuestionIdx].correctAnswerIndex) {
                              setQuizScore(prev => prev + 1);
                            }
                          }}
                          disabled={selectedQuizAnswer === null}
                          className="mt-5 w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold rounded-xl py-2.5 transition-all"
                        >
                          Submit Answer
                        </button>
                      ) : (
                        <div className="mt-5 space-y-4 pt-4 border-t border-slate-850">
                          {/* Explanation and math/logic steps */}
                          <div>
                            <span className="text-[10px] text-indigo-400 font-bold font-mono tracking-wider uppercase block mb-1">
                              Explanation & Insights:
                            </span>
                            <p className="text-xs text-slate-300 leading-relaxed">
                              {generatedQuiz[activeQuestionIdx].explanation}
                            </p>
                          </div>

                          {generatedQuiz[activeQuestionIdx].steps && generatedQuiz[activeQuestionIdx].steps!.length > 0 && (
                            <div>
                              <button
                                onClick={() => setShowQuizSteps(!showQuizSteps)}
                                className="text-[10px] text-slate-400 font-semibold uppercase hover:text-white flex items-center gap-1"
                              >
                                {showQuizSteps ? 'Hide Step-by-Step Solution' : 'View Step-by-Step Solution'}
                              </button>
                              
                              {showQuizSteps && (
                                <ol className="space-y-1.5 mt-2 bg-slate-950 p-3.5 border border-slate-850 rounded-xl">
                                  {generatedQuiz[activeQuestionIdx].steps!.map((step, sIdx) => (
                                    <li key={sIdx} className="text-xs text-slate-400 font-mono leading-relaxed">
                                      <span className="text-indigo-400 font-bold pr-1">{sIdx + 1}.</span> {step}
                                    </li>
                                  ))}
                                </ol>
                              )}
                            </div>
                          )}

                          {/* Navigation */}
                          {activeQuestionIdx < generatedQuiz.length - 1 ? (
                            <button
                              onClick={() => {
                                setActiveQuestionIdx(prev => prev + 1);
                                setSelectedQuizAnswer(null);
                                setIsQuizSubmitted(false);
                                setShowQuizSteps(false);
                              }}
                              className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl py-2.5 transition-all"
                            >
                              Next Question
                            </button>
                          ) : (
                            <div className="flex gap-2">
                              <button
                                onClick={() => {
                                  setActiveQuestionIdx(0);
                                  setSelectedQuizAnswer(null);
                                  setIsQuizSubmitted(false);
                                  setQuizScore(0);
                                  setShowQuizSteps(false);
                                }}
                                className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl py-2.5 transition-all"
                              >
                                Try Quiz Again
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="h-64 flex flex-col items-center justify-center text-slate-500">
                    <HelpCircle className="w-12 h-12 stroke-1 mb-2.5" />
                    <p className="text-sm font-medium">No Mock Test generated yet</p>
                    <p className="text-xs text-slate-500 mt-0.5">Click the "Generate Test" button to build interactive exam practice problems.</p>
                  </div>
                )}
              </div>
            )}

            {/* 5. Learning Roadmaps */}
            {activeTool === 'roadmap' && (
              <div className="h-full max-w-2xl mx-auto">
                {generatedRoadmap ? (
                  <div className="space-y-6">
                    <h2 className="text-lg font-bold text-slate-200 font-display border-b border-slate-850 pb-2">
                      Learning Roadmap & Syllabus Guide
                    </h2>
                    
                    <div className="relative pl-6 border-l border-indigo-900/60 space-y-8">
                      {generatedRoadmap.map((step, idx) => (
                        <div key={idx} className="relative">
                          {/* Progress Circle Node */}
                          <span className="absolute -left-[31px] top-1.5 w-4 h-4 rounded-full bg-indigo-600 border-4 border-slate-900 flex items-center justify-center"></span>

                          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl shadow-lg">
                            <span className="text-[10px] font-mono text-indigo-400 font-bold uppercase block mb-0.5">
                              {step.stage}
                            </span>
                            <h4 className="text-sm md:text-base font-bold text-slate-100">
                              {step.title}
                            </h4>
                            <p className="text-xs text-slate-400 leading-relaxed mt-1.5 font-normal">
                              {step.description}
                            </p>

                            <div className="mt-3.5 flex flex-wrap gap-1.5">
                              {step.keyConcepts.map((concept, cIdx) => (
                                <span key={cIdx} className="text-[10px] bg-slate-950 text-slate-400 px-2 py-0.5 rounded font-mono">
                                  {concept}
                                </span>
                              ))}
                            </div>

                            <div className="mt-3 pt-3 border-t border-slate-850">
                              <span className="text-[9px] font-mono uppercase text-slate-500 font-bold block mb-1">
                                High-Quality Resources:
                              </span>
                              <div className="flex flex-wrap gap-2">
                                {step.recommendedResources.map((res, rIdx) => (
                                  <span key={rIdx} className="text-[10px] text-indigo-300 font-semibold bg-indigo-950/15 border border-indigo-900/10 px-2.5 py-1 rounded">
                                    {res}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="h-64 flex flex-col items-center justify-center text-slate-500">
                    <Compass className="w-12 h-12 stroke-1 mb-2.5" />
                    <p className="text-sm font-medium">No Learning Roadmap generated yet</p>
                    <p className="text-xs text-slate-500 mt-0.5">Click the "Generate Roadmap" button to model educational paths.</p>
                  </div>
                )}
              </div>
            )}

            {/* 6. Comparison Grid */}
            {activeTool === 'comparison' && (
              <div className="h-full">
                {generatedComparison ? (
                  <div className="max-w-3xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl overflow-x-auto">
                    <h3 className="text-lg font-bold text-slate-200 font-display mb-4 border-b border-slate-800 pb-2">
                      {generatedComparison.title}
                    </h3>
                    <table className="w-full text-left border-collapse min-w-[500px]">
                      <thead>
                        <tr className="border-b border-slate-800 bg-slate-950">
                          {generatedComparison.headers.map((header, hIdx) => (
                            <th key={hIdx} className="p-3 text-xs font-mono uppercase text-indigo-400 font-bold">
                              {header}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {generatedComparison.rows.map((row, rIdx) => (
                          <tr key={rIdx} className="border-b border-slate-850 hover:bg-slate-900/50 transition-colors">
                            <td className="p-3 text-xs font-semibold text-slate-200 font-display max-w-[150px]">
                              {row.concept}
                            </td>
                            {row.values.map((val, vIdx) => (
                              <td key={vIdx} className="p-3 text-xs text-slate-300 leading-relaxed font-sans font-normal">
                                {val}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="h-64 flex flex-col items-center justify-center text-slate-500">
                    <Table className="w-12 h-12 stroke-1 mb-2.5" />
                    <p className="text-sm font-medium">No Comparison Grid generated yet</p>
                    <p className="text-xs text-slate-500 mt-0.5">Click the "Generate Comparison" button to study concepts side-by-side.</p>
                  </div>
                )}
              </div>
            )}

            {/* 7. Formula Sheets */}
            {activeTool === 'formulas' && (
              <div className="h-full max-w-3xl mx-auto">
                {generatedFormulas ? (
                  <div className="space-y-6">
                    <h2 className="text-lg font-bold text-slate-200 font-display border-b border-slate-805 pb-2">
                      {generatedFormulas.title}
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {generatedFormulas.formulas.map((form, idx) => (
                        <div key={idx} className="p-5 bg-slate-900 border border-slate-800 rounded-xl shadow-lg flex flex-col justify-between">
                          <div>
                            <span className="text-[10px] font-mono text-indigo-400 font-bold block mb-1">
                              EQUATION
                            </span>
                            <h4 className="text-sm font-bold text-slate-100 mb-2">
                              {form.name}
                            </h4>
                            <div className="p-3 bg-slate-950 border border-slate-850 rounded-lg text-center font-mono text-slate-100 text-sm tracking-wide font-bold mb-3.5 select-all">
                              {form.equation}
                            </div>
                            
                            <div className="space-y-1 text-[11px] text-slate-400">
                              <span className="font-semibold text-[10px] text-slate-500 font-mono uppercase block">Variables:</span>
                              {form.variables.map((variable, vIdx) => (
                                <p key={vIdx} className="font-sans">• {variable}</p>
                              ))}
                            </div>
                          </div>

                          <div className="mt-4 pt-3.5 border-t border-slate-850">
                            <span className="text-[10px] text-indigo-400 font-semibold font-mono uppercase block mb-1">
                              Calculated Example:
                            </span>
                            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-2.5 rounded-lg border border-slate-900 font-mono">
                              {form.application}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="h-64 flex flex-col items-center justify-center text-slate-500">
                    <BookOpen className="w-12 h-12 stroke-1 mb-2.5" />
                    <p className="text-sm font-medium">No Formula Sheets generated yet</p>
                    <p className="text-xs text-slate-500 mt-0.5">Click the "Generate Formulas" button to compile formulas, variables, and solutions.</p>
                  </div>
                )}
              </div>
            )}

            {/* 8. Concept Mindmap */}
            {activeTool === 'mindmap' && (
              <div className="h-full max-w-3xl mx-auto">
                {generatedMindmap ? (
                  <div className="space-y-4">
                    <h3 className="text-sm font-semibold tracking-wide text-slate-300 uppercase flex items-center gap-2">
                      <Brain className="w-4 h-4 text-indigo-400" />
                      Visual Concept Map
                    </h3>

                    {/* Interactive SVG Mindmap */}
                    <div className="relative border border-slate-800 bg-slate-950 rounded-2xl overflow-hidden shadow-2xl flex items-center justify-center">
                      <svg 
                        viewBox="0 0 600 400" 
                        className="w-full h-[400px] select-none text-white font-sans"
                      >
                        {/* Define glowing node filters */}
                        <defs>
                          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                            <feGaussianBlur stdDeviation="6" result="blur" />
                            <feComposite in="SourceGraphic" in2="blur" operator="over" />
                          </filter>
                        </defs>

                        {/* Draw link relationships lines */}
                        {generatedMindmap.links.map((link, idx) => {
                          const srcIdx = generatedMindmap.nodes.findIndex(n => n.id === link.source);
                          const trgIdx = generatedMindmap.nodes.findIndex(n => n.id === link.target);
                          if (srcIdx === -1 || trgIdx === -1) return null;

                          const srcCoords = getMindmapCoords(srcIdx, generatedMindmap.nodes.length);
                          const trgCoords = getMindmapCoords(trgIdx, generatedMindmap.nodes.length);

                          const midX = (srcCoords.x + trgCoords.x) / 2;
                          const midY = (srcCoords.y + trgCoords.y) / 2;

                          return (
                            <g key={`l-${idx}`}>
                              <line
                                x1={srcCoords.x}
                                y1={srcCoords.y}
                                x2={trgCoords.x}
                                y2={trgCoords.y}
                                stroke="#4338ca"
                                strokeWidth="1.5"
                                strokeDasharray={generatedMindmap.nodes[trgIdx].type === 'detail' ? "4 4" : "none"}
                                opacity="0.6"
                              />
                              {/* Relationship small text badge */}
                              <rect
                                x={midX - 35}
                                y={midY - 8}
                                width={70}
                                height={16}
                                rx={4}
                                fill="#0f172a"
                                stroke="#1e293b"
                                strokeWidth="0.5"
                              />
                              <text
                                x={midX}
                                y={midY + 3}
                                textAnchor="middle"
                                className="text-[8px] font-mono font-medium fill-slate-400 uppercase"
                              >
                                {link.relationship}
                              </text>
                            </g>
                          );
                        })}

                        {/* Draw concept nodes */}
                        {generatedMindmap.nodes.map((node, idx) => {
                          const coords = getMindmapCoords(idx, generatedMindmap.nodes.length);
                          const isHovered = hoveredConceptNode === node.id;
                          
                          let fill = '#1e1b4b'; // deep indigo for main
                          let stroke = '#6366f1';
                          let textFill = '#ffffff';
                          let radius = 45;

                          if (node.type === 'sub') {
                            fill = '#0f172a'; // dark slate for sub
                            stroke = '#818cf8';
                            radius = 36;
                          } else if (node.type === 'detail') {
                            fill = '#030712'; // darker gray for deep detail
                            stroke = '#94a3b8';
                            radius = 28;
                          }

                          return (
                            <g 
                              key={node.id}
                              onMouseEnter={() => setHoveredConceptNode(node.id)}
                              onMouseLeave={() => setHoveredConceptNode(null)}
                              className="cursor-pointer transition-all duration-300"
                              transform={`translate(${coords.x}, ${coords.y})`}
                            >
                              <circle
                                r={radius}
                                fill={fill}
                                stroke={isHovered ? '#10b981' : stroke}
                                strokeWidth={isHovered ? 3 : 1.5}
                                filter={isHovered ? "url(#glow)" : ""}
                                className="transition-all duration-200"
                              />
                              {/* Multiline Text truncation helper */}
                              <text
                                textAnchor="middle"
                                y={4}
                                className={`fill-slate-100 font-semibold pointer-events-none ${
                                  node.type === 'main' ? 'text-[11px]' : 'text-[9px]'
                                }`}
                              >
                                {node.label.length > 12 ? `${node.label.substring(0, 10)}...` : node.label}
                              </text>
                            </g>
                          );
                        })}
                      </svg>

                      {/* Floating node metadata tooltip */}
                      {hoveredConceptNode && (
                        <div className="absolute bottom-4 left-4 right-4 p-3.5 bg-slate-900/90 border border-slate-800 rounded-xl shadow-2xl backdrop-blur-md">
                          <p className="text-[10px] font-mono text-indigo-400 uppercase font-bold">
                            {generatedMindmap.nodes.find(n => n.id === hoveredConceptNode)?.type} Node
                          </p>
                          <h4 className="text-xs font-bold text-slate-100">
                            {generatedMindmap.nodes.find(n => n.id === hoveredConceptNode)?.label}
                          </h4>
                          <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                            This node represents a core term or conceptual pillar defined in the study material. Hover over other nodes or relationships to inspect logical connections.
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="h-64 flex flex-col items-center justify-center text-slate-500">
                    <Brain className="w-12 h-12 stroke-1 mb-2.5" />
                    <p className="text-sm font-medium">No Concept Map generated yet</p>
                    <p className="text-xs text-slate-500 mt-0.5">Click the "Generate Mindmap" button to visualize links between terms.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
