import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Sparkles, 
  BookOpen, 
  Check, 
  ArrowRight, 
  GraduationCap, 
  Globe, 
  RefreshCw,
  HelpCircle,
  AlertCircle,
  ExternalLink
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { ChatMessage, StudyMaterial } from '../types';

interface TutorChatProps {
  messages: ChatMessage[];
  setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  activeMaterials: StudyMaterial[];
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'none';
  setDifficulty: React.Dispatch<React.SetStateAction<'beginner' | 'intermediate' | 'advanced' | 'none'>>;
  currentTopic: string;
}

export default function TutorChat({
  messages,
  setMessages,
  activeMaterials,
  difficulty,
  setDifficulty,
  currentTopic
}: TutorChatProps) {
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of conversation
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle message sending
  const handleSendMessage = async (textToSend: string, forceDifficulty?: 'beginner' | 'intermediate' | 'advanced') => {
    if (!textToSend.trim() || isSending) return;

    const studentMessage: ChatMessage = {
      id: `msg-${Date.now()}-student`,
      sender: 'student',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, studentMessage]);
    setInputText('');
    setIsSending(true);

    const selectedDifficulty = forceDifficulty || (difficulty === 'none' ? undefined : difficulty);

    try {
      const response = await fetch('/api/study/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, studentMessage],
          activeMaterials: activeMaterials,
          topic: currentTopic,
          difficulty: selectedDifficulty
        })
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to communicate with your Study Partner.');
      }

      const result = await response.json();

      // Extract suggestions or custom markdown structures if present
      const suggestedQuestions = extractSuggestedQuestions(result.text);

      const tutorMessage: ChatMessage = {
        id: `msg-${Date.now()}-tutor`,
        sender: 'tutor',
        text: result.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        difficulty: selectedDifficulty,
        citations: result.citations,
        suggestedQuestions: suggestedQuestions.length > 0 ? suggestedQuestions : undefined
      };

      setMessages(prev => [...prev, tutorMessage]);
    } catch (error: any) {
      console.error(error);
      let errorText = `⚠️ **Study Partner connection error:** ${error.message || 'The server had a glitch. Please try again!'}`;
      
      const lowercaseErr = (error.message || '').toLowerCase();
      if (lowercaseErr.includes('quota') || lowercaseErr.includes('exhausted') || lowercaseErr.includes('billing') || lowercaseErr.includes('429')) {
        errorText += `\n\n💡 **Rate Limit or Quota Reached:** It looks like the configured Gemini API key has exceeded its limits or requires a paid/billing configuration. You can update or supply your own API key under the **Settings > Secrets** panel in AI Studio.`;
      }

      const errorMessage: ChatMessage = {
        id: `msg-${Date.now()}-err`,
        sender: 'tutor',
        text: errorText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsSending(false);
    }
  };

  // Extract follow up questions from markdown responses or generate generic ones
  const extractSuggestedQuestions = (text: string): string[] => {
    const suggestions: string[] = [];
    const practiceRegex = /(?:practice question|try this|test your understanding|question for you|quiz question):\s*\*?([^\n*?]+)\??/gi;
    const match = practiceRegex.exec(text);
    if (match && match[1]) {
      suggestions.push(match[1].trim() + "?");
    }

    // Default curious next suggestions
    if (text.toLowerCase().includes('equation') || text.toLowerCase().includes('formula')) {
      suggestions.push("Can you show a step-by-step example problem?");
    }
    suggestions.push("Can you give me a real-world analogy to remember this?");
    suggestions.push("How would you summarize this concept for an exam?");

    // Limit and shuffle slightly
    return Array.from(new Set(suggestions)).slice(0, 3);
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputText);
  };

  // Let student trigger deeper explanations dynamically
  const requestProgressiveLevel = (level: 'beginner' | 'intermediate' | 'advanced') => {
    setDifficulty(level);
    const lastTutorMsg = [...messages].reverse().find(m => m.sender === 'tutor');
    let promptMsg = `Could you explain the concepts we just discussed but adapt it specifically as a **${level.toUpperCase()}** explanation?`;
    
    if (level === 'beginner') {
      promptMsg += ` (Use highly relatable real-world analogies, simpler language, and structural models)`;
    } else if (level === 'intermediate') {
      promptMsg += ` (Use structured concepts, definitions, and logical flow diagrams)`;
    } else if (level === 'advanced') {
      promptMsg += ` (Focus on core mathematical formulas, proof derivations, detailed mechanical systems, or formal code patterns)`;
    }

    handleSendMessage(promptMsg, level);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/40 border border-slate-800 rounded-2xl overflow-hidden">
      {/* Tutor Header Area */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-lg">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="font-semibold text-slate-100 text-sm">Study Partner</h2>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Ready to tutor"></span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono">
              {activeMaterials.length > 0 
                ? `${activeMaterials.length} Study Material(s) loaded` 
                : 'General Knowledge & Science Mode'}
            </p>
          </div>
        </div>

        {/* Explain Mode Controls */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-400 font-medium tracking-wide uppercase hidden sm:inline">
            Tutor Level:
          </span>
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            {(['none', 'beginner', 'intermediate', 'advanced'] as const).map((level) => (
              <button
                key={level}
                onClick={() => setDifficulty(level)}
                className={`px-2 py-1 text-[10px] font-medium rounded-md transition-all uppercase ${
                  difficulty === level 
                    ? 'bg-indigo-600 text-white' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {level === 'none' ? 'Concise' : level}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* active context banner */}
      {activeMaterials.length > 0 && (
        <div className="bg-indigo-950/20 px-4 py-2 border-b border-indigo-900/30 flex items-center gap-2">
          <BookOpen className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" />
          <p className="text-[10px] text-indigo-300 font-medium truncate">
            Current session grounded in: <span className="text-slate-200 font-semibold">{activeMaterials.map(m => m.name).join(', ')}</span>
          </p>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 md:p-6 overflow-y-auto space-y-6">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center py-12 px-6">
            <div className="w-14 h-14 bg-indigo-950/50 rounded-2xl flex items-center justify-center mb-4 border border-indigo-900/40">
              <Sparkles className="w-7 h-7 text-indigo-400" />
            </div>
            <h3 className="text-lg font-semibold text-slate-200 font-display">Let's learn something new!</h3>
            <p className="text-sm text-slate-400 max-w-md mt-2 leading-relaxed">
              Ask me any question in Mathematics, Science, Engineering, History, or Programming. Or, upload a lecture slide or syllabus to start a personal tutoring session!
            </p>
            <div className="mt-6 flex flex-col gap-2 max-w-sm w-full">
              <button 
                onClick={() => handleSendMessage("How do I solve equations step-by-step?")}
                className="text-left text-xs bg-slate-900/60 border border-slate-800 hover:border-slate-700 hover:bg-slate-900 rounded-xl p-3 text-slate-300 transition-all flex items-center justify-between group"
              >
                <span>"How do I solve equations step-by-step?"</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300 transition-colors" />
              </button>
              <button 
                onClick={() => handleSendMessage("Explain quantum physics in extremely simple terms.")}
                className="text-left text-xs bg-slate-900/60 border border-slate-800 hover:border-slate-700 hover:bg-slate-900 rounded-xl p-3 text-slate-300 transition-all flex items-center justify-between group"
              >
                <span>"Explain quantum physics in simple terms"</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300 transition-colors" />
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {messages.map((msg) => {
              const isStudent = msg.sender === 'student';
              return (
                <div 
                  key={msg.id}
                  className={`flex flex-col ${isStudent ? 'items-end' : 'items-start'}`}
                >
                  <div className={`max-w-[85%] md:max-w-[75%] rounded-2xl p-4 md:p-5 ${
                    isStudent 
                      ? 'bg-indigo-600 text-white shadow-md' 
                      : 'bg-slate-900/80 border border-slate-800 text-slate-200 shadow-sm'
                  }`}>
                    <div className="markdown-body text-sm leading-relaxed font-sans prose prose-invert max-w-none">
                      <ReactMarkdown>{msg.text}</ReactMarkdown>
                    </div>

                    {/* Citations & Sources (Google Search Grounding) */}
                    {!isStudent && msg.citations && msg.citations.length > 0 && (
                      <div className="mt-4 pt-3 border-t border-slate-800/80">
                        <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium mb-2">
                          <Globe className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Sources verified from Google Search:</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {msg.citations.map((cite, idx) => (
                            <a
                              key={idx}
                              href={cite.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[10px] bg-slate-800 hover:bg-slate-750 text-indigo-300 font-medium px-2 py-1 rounded-lg border border-slate-700 transition-all"
                            >
                              <span>{cite.title || 'Source'}</span>
                              <ExternalLink className="w-2.5 h-2.5 text-slate-500" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Tutor Depth Controller Pills (Show at the bottom of a tutor answer) */}
                    {!isStudent && (
                      <div className="mt-4 pt-3 border-t border-slate-850 flex flex-wrap items-center gap-2">
                        <span className="text-[10px] text-slate-500 font-semibold font-mono tracking-wide uppercase">
                          Change explanation depth:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          <button
                            onClick={() => requestProgressiveLevel('beginner')}
                            className="text-[10px] font-medium bg-slate-800 hover:bg-indigo-950/40 hover:text-indigo-300 text-slate-300 border border-slate-700 hover:border-indigo-800/40 px-2.5 py-1 rounded-md transition-all"
                          >
                            🎓 Beginner
                          </button>
                          <button
                            onClick={() => requestProgressiveLevel('intermediate')}
                            className="text-[10px] font-medium bg-slate-800 hover:bg-indigo-950/40 hover:text-indigo-300 text-slate-300 border border-slate-700 hover:border-indigo-800/40 px-2.5 py-1 rounded-md transition-all"
                          >
                            📘 Intermediate
                          </button>
                          <button
                            onClick={() => requestProgressiveLevel('advanced')}
                            className="text-[10px] font-medium bg-slate-800 hover:bg-indigo-950/40 hover:text-indigo-300 text-slate-300 border border-slate-700 hover:border-indigo-800/40 px-2.5 py-1 rounded-md transition-all"
                          >
                            🔬 Advanced
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Time and level details */}
                  <span className="text-[10px] text-slate-500 font-mono mt-1.5 px-1 flex items-center gap-1.5">
                    {msg.timestamp}
                    {msg.difficulty && (
                      <span className="uppercase text-[9px] font-semibold bg-slate-800 px-1.5 py-0.5 rounded text-indigo-400">
                        {msg.difficulty} explain
                      </span>
                    )}
                  </span>

                  {/* Suggested continuation prompts */}
                  {!isStudent && msg.suggestedQuestions && msg.suggestedQuestions.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-2 max-w-[85%] self-start pl-2">
                      {msg.suggestedQuestions.map((q, i) => (
                        <button
                          key={i}
                          onClick={() => handleSendMessage(q)}
                          className="text-left text-xs text-indigo-300 bg-slate-900/40 border border-indigo-950 hover:bg-slate-900 hover:border-indigo-800 px-3 py-1.5 rounded-xl transition-all font-medium"
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={onSubmit} className="p-4 bg-slate-900 border-t border-slate-800">
        <div className="flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={isSending ? "Study Partner is formulating explanation..." : "Ask Study Partner to explain, solve or audit..."}
            disabled={isSending}
            className="flex-1 bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none disabled:opacity-60 transition-all font-sans"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isSending}
            className="p-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white rounded-xl transition-all shadow-md flex items-center justify-center w-12"
          >
            {isSending ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
