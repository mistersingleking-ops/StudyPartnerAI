import React, { useState, useRef } from 'react';
import { 
  FileText, 
  UploadCloud, 
  Check, 
  Trash2, 
  AlertTriangle, 
  Layers, 
  BookOpen, 
  Brain, 
  HelpCircle,
  Sparkles,
  RefreshCw,
  Eye,
  FileSpreadsheet,
  FileImage,
  Presentation
} from 'lucide-react';
import { StudyMaterial } from '../types';

interface MaterialManagerProps {
  materials: StudyMaterial[];
  setMaterials: React.Dispatch<React.SetStateAction<StudyMaterial[]>>;
  activeMaterialIds: string[];
  setActiveMaterialIds: React.Dispatch<React.SetStateAction<string[]>>;
}

export default function MaterialManager({
  materials,
  setMaterials,
  activeMaterialIds,
  setActiveMaterialIds,
}: MaterialManagerProps) {
  const [dragActive, setDragActive] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [parseStatus, setParseStatus] = useState('');
  const [auditingId, setAuditingId] = useState<string | null>(null);
  const [selectedAuditMaterial, setSelectedAuditMaterial] = useState<StudyMaterial | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Toggle material active state
  const toggleMaterialActive = (id: string) => {
    setActiveMaterialIds(prev => {
      if (prev.includes(id)) {
        return prev.filter(mId => mId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  // Delete material
  const deleteMaterial = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setMaterials(prev => prev.filter(m => m.id !== id));
    setActiveMaterialIds(prev => prev.filter(mId => mId !== id));
    if (selectedAuditMaterial?.id === id) {
      setSelectedAuditMaterial(null);
    }
  };

  // Convert file to base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        // strip prefix like "data:application/pdf;base64,"
        const base64 = result.split(',')[1];
        resolve(base64);
      };
      reader.onerror = error => reject(error);
    });
  };

  // Process selected file
  const processFile = async (file: File) => {
    if (!file) return;

    setIsParsing(true);
    setParseStatus(`Reading ${file.name}...`);

    try {
      const base64 = await fileToBase64(file);
      const ext = file.name.split('.').pop()?.toLowerCase();
      
      let type: 'pdf' | 'docx' | 'pptx' | 'xlsx' | 'text' | 'image' = 'text';
      let mimeType = file.type;

      if (ext === 'pdf') type = 'pdf';
      else if (ext === 'docx') type = 'docx';
      else if (ext === 'pptx' || ext === 'ppt') type = 'pptx';
      else if (ext === 'xlsx' || ext === 'xls' || ext === 'csv') type = 'xlsx';
      else if (['png', 'jpg', 'jpeg', 'webp', 'gif'].includes(ext || '')) type = 'image';

      setParseStatus(`Analyzing and parsing text structure...`);

      // Call backend to parse
      const parseResponse = await fetch('/api/study/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: file.name.replace(/\.[^/.]+$/, ""),
          fileType: type,
          base64Data: base64
        })
      });

      if (!parseResponse.ok) {
        throw new Error('Failed to parse file on server.');
      }

      const parseResult = await parseResponse.json();

      const newMaterial: StudyMaterial = {
        id: `mat-${Date.now()}`,
        name: file.name,
        type: type,
        size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
        parsedText: parseResult.text,
        base64Data: base64,
        mimeType: mimeType
      };

      setMaterials(prev => [newMaterial, ...prev]);
      // Auto-activate new uploads
      setActiveMaterialIds(prev => [...prev, newMaterial.id]);
      
      setParseStatus('');
    } catch (err: any) {
      console.error(err);
      alert(`Error processing file: ${err.message || 'Unknown error'}`);
    } finally {
      setIsParsing(false);
    }
  };

  // File drag handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  // Perform deep AI Audit
  const performAudit = async (material: StudyMaterial) => {
    if (material.analyzedReport) {
      setSelectedAuditMaterial(material);
      return;
    }

    setAuditingId(material.id);
    try {
      const response = await fetch('/api/study/analyze-material', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: material.name,
          fileType: material.type,
          textContent: material.parsedText,
          base64Data: material.base64Data
        })
      });

      if (!response.ok) {
        throw new Error('Failed to run audit on document.');
      }

      const result = await response.json();
      
      setMaterials(prev => prev.map(m => {
        if (m.id === material.id) {
          const updated = { ...m, analyzedReport: result.report };
          setSelectedAuditMaterial(updated);
          return updated;
        }
        return m;
      }));

    } catch (err: any) {
      console.error(err);
      alert(`AI Audit failed: ${err.message}`);
    } finally {
      setAuditingId(null);
    }
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return <FileText className="w-8 h-8 text-rose-400" />;
      case 'docx':
        return <FileText className="w-8 h-8 text-blue-400" />;
      case 'pptx':
        return <Presentation className="w-8 h-8 text-amber-400" />;
      case 'xlsx':
        return <FileSpreadsheet className="w-8 h-8 text-emerald-400" />;
      case 'image':
        return <FileImage className="w-8 h-8 text-violet-400" />;
      default:
        return <FileText className="w-8 h-8 text-slate-400" />;
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
      {/* File Upload and Selector */}
      <div className={`col-span-1 h-full flex flex-col ${selectedAuditMaterial ? 'lg:col-span-5' : 'lg:col-span-12'} transition-all duration-300`}>
        {/* Drag and Drop Zone */}
        <div 
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={triggerFileInput}
          className={`relative border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-200 group h-44 bg-slate-800/40 ${
            dragActive 
              ? 'border-indigo-500 bg-indigo-500/10' 
              : 'border-slate-700 hover:border-slate-500 hover:bg-slate-800/60'
          }`}
        >
          <input 
            ref={fileInputRef}
            type="file" 
            className="hidden" 
            onChange={handleFileInput}
            accept=".pdf,.docx,.doc,.pptx,.ppt,.xlsx,.xls,.txt,.csv,.png,.jpg,.jpeg,.webp"
          />

          {isParsing ? (
            <div className="flex flex-col items-center gap-3">
              <RefreshCw className="w-10 h-10 text-indigo-400 animate-spin" />
              <p className="text-slate-300 text-sm font-medium">{parseStatus}</p>
            </div>
          ) : (
            <>
              <div className="p-3 bg-slate-800 rounded-xl mb-3 group-hover:scale-110 transition-transform duration-200">
                <UploadCloud className="w-6 h-6 text-indigo-400" />
              </div>
              <h3 className="font-semibold text-slate-100 text-sm">Upload Study Material</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-md px-4">
                Drag & drop or click to browse. Supports PDFs, Word documents, PowerPoints, Spreadsheets, Notes images, or Text files.
              </p>
            </>
          )}
        </div>

        {/* Uploaded Materials List */}
        <div className="flex-1 mt-6 overflow-y-auto pr-1">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              <h3 className="text-sm font-semibold tracking-wide text-slate-300 uppercase">
                My Materials ({materials.length})
              </h3>
            </div>
            {materials.length > 0 && (
              <span className="text-[10px] font-medium bg-indigo-950 text-indigo-300 px-2.5 py-0.5 rounded-full">
                {activeMaterialIds.length} ACTIVE
              </span>
            )}
          </div>

          {materials.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-slate-500 border border-slate-800/60 rounded-2xl bg-slate-900/40">
              <BookOpen className="w-10 h-10 stroke-1 mb-2" />
              <p className="text-sm font-medium text-slate-400">No documents uploaded yet</p>
              <p className="text-xs text-slate-500 mt-1">Upload slides, notes or syllabus files to start tutoring</p>
            </div>
          ) : (
            <div className="space-y-3">
              {materials.map(material => {
                const isActive = activeMaterialIds.includes(material.id);
                const hasReport = !!material.analyzedReport;
                const isAuditing = auditingId === material.id;
                
                return (
                  <div
                    key={material.id}
                    onClick={() => toggleMaterialActive(material.id)}
                    className={`p-4 rounded-xl border flex items-center justify-between gap-4 cursor-pointer transition-all duration-200 ${
                      isActive 
                        ? 'bg-indigo-950/20 border-indigo-500/50 shadow-[0_0_12px_rgba(99,102,241,0.05)]' 
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3.5 flex-1 min-w-0">
                      <div className="relative flex-shrink-0">
                        {getFileIcon(material.type)}
                        {isActive && (
                          <div className="absolute -top-1 -right-1 bg-indigo-500 text-white rounded-full p-0.5 border border-slate-900">
                            <Check className="w-2.5 h-2.5" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-200 truncate group-hover:text-white">
                          {material.name}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[10px] font-mono text-slate-400 uppercase bg-slate-800 px-1.5 py-0.5 rounded">
                            {material.type}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {material.size}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
                      <button
                        onClick={() => performAudit(material)}
                        disabled={isAuditing}
                        className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-all ${
                          hasReport
                            ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/40 hover:bg-emerald-950/60'
                            : 'bg-indigo-900/30 text-indigo-300 border border-indigo-800/30 hover:bg-indigo-900/50'
                        }`}
                        title="AI audit details & conceptual validation reports"
                      >
                        {isAuditing ? (
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        ) : hasReport ? (
                          <Sparkles className="w-3.5 h-3.5" />
                        ) : (
                          <Brain className="w-3.5 h-3.5" />
                        )}
                        <span className="hidden sm:inline font-medium">
                          {isAuditing ? 'Auditing...' : hasReport ? 'See Audit' : 'AI Concept Audit'}
                        </span>
                      </button>

                      <button
                        onClick={(e) => deleteMaterial(material.id, e)}
                        className="p-2 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800/60 transition-all"
                        title="Delete document"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* AI Concept Audit Display Column */}
      {selectedAuditMaterial && (
        <div className="col-span-1 lg:col-span-7 h-full flex flex-col border border-slate-800 bg-slate-900/60 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in slide-in-from-right-4 duration-300">
          <div className="p-5 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <h3 className="font-semibold text-slate-100 flex items-center gap-1 text-sm md:text-base">
                AI Audit Report
              </h3>
              <span className="text-[10px] text-emerald-400 font-medium font-mono uppercase bg-emerald-950 border border-emerald-900/50 px-2 py-0.5 rounded">
                Verified
              </span>
            </div>
            <button 
              onClick={() => setSelectedAuditMaterial(null)}
              className="text-slate-400 hover:text-white text-xs bg-slate-800 px-2.5 py-1 rounded-lg"
            >
              Close
            </button>
          </div>

          <div className="p-6 overflow-y-auto flex-1 space-y-6">
            <div>
              <h4 className="text-slate-400 font-semibold text-xs tracking-wider uppercase mb-1.5">Document Overview</h4>
              <p className="text-sm text-slate-300 leading-relaxed font-sans">
                {selectedAuditMaterial.analyzedReport?.overview}
              </p>
            </div>

            {/* Inconsistencies & Possible Errors (Important Feature requested!) */}
            <div>
              <h4 className="text-rose-400 font-semibold text-xs tracking-wider uppercase mb-2.5 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                Material Inconsistencies & Potential Errors
              </h4>
              {selectedAuditMaterial.analyzedReport?.inconsistencies && selectedAuditMaterial.analyzedReport.inconsistencies.length > 0 ? (
                <ul className="space-y-2">
                  {selectedAuditMaterial.analyzedReport.inconsistencies.map((inc, i) => (
                    <li key={i} className="flex gap-2.5 text-xs text-rose-200 bg-rose-950/15 border border-rose-900/20 p-3 rounded-lg leading-relaxed">
                      <span className="font-semibold text-rose-400 flex-shrink-0 font-mono">!</span>
                      <p>{inc}</p>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="p-3 bg-emerald-950/10 border border-emerald-900/20 rounded-lg text-xs text-emerald-300 flex gap-2 items-center">
                  <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>Perfect Score! No logical errors, definitions conflicts, or severe terminology contradictions were found.</span>
                </div>
              )}
            </div>

            {/* Key Concepts defined */}
            <div>
              <h4 className="text-indigo-400 font-semibold text-xs tracking-wider uppercase mb-2.5 flex items-center gap-1.5">
                <Brain className="w-4 h-4" />
                Extracted Academic Definitions & Key Concepts
              </h4>
              <div className="space-y-3">
                {selectedAuditMaterial.analyzedReport?.keyConcepts.map((concept, i) => (
                  <div key={i} className="p-3 bg-slate-950/40 border border-slate-800/80 rounded-lg">
                    <span className="text-xs font-semibold text-slate-100 block mb-1">
                      {concept.name}
                    </span>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {concept.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Omitted Information / Missing Details */}
            <div>
              <h4 className="text-amber-400 font-semibold text-xs tracking-wider uppercase mb-2.5 flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4" />
                Missing Background Information
              </h4>
              <ul className="space-y-1.5">
                {selectedAuditMaterial.analyzedReport?.missingInfo.map((info, i) => (
                  <li key={i} className="flex gap-2 text-xs text-slate-300 items-start">
                    <span className="text-amber-400 font-semibold font-mono flex-shrink-0">•</span>
                    <p>{info}</p>
                  </li>
                ))}
              </ul>
            </div>

            {/* Related Fields to Explore */}
            <div className="pt-2 border-t border-slate-800/80">
              <h4 className="text-slate-400 font-semibold text-[10px] tracking-wider uppercase mb-2">Curious Pathways to Explore Next</h4>
              <div className="flex flex-wrap gap-2">
                {selectedAuditMaterial.analyzedReport?.suggestedTopics.map((topic, i) => (
                  <span 
                    key={i}
                    className="text-xs bg-slate-800 text-slate-300 font-medium px-2.5 py-1 rounded-lg border border-slate-700/60"
                  >
                    {topic}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
