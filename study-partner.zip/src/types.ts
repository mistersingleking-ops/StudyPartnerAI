export interface ChatMessage {
  id: string;
  sender: 'student' | 'tutor';
  text: string;
  timestamp: string;
  difficulty?: 'beginner' | 'intermediate' | 'advanced';
  citations?: { title: string; url: string }[];
  suggestedQuestions?: string[];
}

export interface StudyMaterial {
  id: string;
  name: string;
  type: 'pdf' | 'docx' | 'pptx' | 'xlsx' | 'text' | 'image';
  size: string;
  parsedText?: string;
  base64Data?: string; // used for sending to Gemini directly
  mimeType?: string;
  analyzedReport?: {
    overview: string;
    keyConcepts: { name: string; description: string }[];
    inconsistencies: string[];
    missingInfo: string[];
    suggestedTopics: string[];
  };
}

export interface Flashcard {
  id: string;
  question: string;
  answer: string;
  hint: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
  steps?: string[];
}

export interface PresentationSlide {
  title: string;
  bulletPoints: string[];
  layout: 'intro' | 'content' | 'comparison' | 'conclusion';
  summary: string;
}

export interface StudyNotes {
  title: string;
  sections: {
    heading: string;
    content: string;
    subsections?: { subheading: string; details: string }[];
  }[];
  cheatSheet: string[];
}

export interface ConceptNode {
  id: string;
  label: string;
  type: 'main' | 'sub' | 'detail';
}

export interface ConceptLink {
  source: string;
  target: string;
  relationship: string;
}

export interface ConceptMap {
  nodes: ConceptNode[];
  links: ConceptLink[];
}

export interface RoadmapStep {
  stage: string;
  title: string;
  description: string;
  keyConcepts: string[];
  recommendedResources: string[];
}

export interface ComparisonTable {
  title: string;
  headers: string[];
  rows: {
    concept: string;
    values: string[];
  }[];
}

export interface Formula {
  name: string;
  equation: string;
  variables: string[];
  application: string;
}

export interface FormulaSheet {
  title: string;
  formulas: Formula[];
}
