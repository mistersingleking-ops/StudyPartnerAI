import React, { useState } from 'react';
import { 
  GraduationCap, 
  FolderOpen, 
  Sparkles, 
  Brain, 
  Layers, 
  BookOpen, 
  Flame, 
  Cpu, 
  Clock, 
  Trophy 
} from 'lucide-react';
import TutorChat from './components/TutorChat';
import MaterialManager from './components/MaterialManager';
import StudyToolkit from './components/StudyToolkit';
import { ChatMessage, StudyMaterial } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'tutor' | 'materials' | 'toolkit'>('tutor');
  
  // App-wide state
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [activeMaterialIds, setActiveMaterialIds] = useState<string[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [difficulty, setDifficulty] = useState<'beginner' | 'intermediate' | 'advanced' | 'none'>('none');
  const [currentTopic, setCurrentTopic] = useState('Photosynthesis');

  // Compute active materials array
  const activeMaterials = materials.filter(m => activeMaterialIds.includes(m.id));

  // Determine active topic based on materials or selection
  const sessionTopic = activeMaterials.length > 0 
    ? activeMaterials[0].name.replace(/\.[^/.]+$/, "") 
    : currentTopic;

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex flex-col font-sans">
      {/* Premium Dashboard Header */}
      <header className="bg-slate-900/80 border-b border-slate-800 backdrop-blur-md sticky top-0 z-40 px-4 py-3 md:px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-lg shadow-indigo-950/40 relative">
              <Brain className="w-5.5 h-5.5" />
              <div className="absolute -inset-0.5 bg-indigo-500 rounded-xl blur opacity-30 animate-pulse"></div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-base md:text-lg font-bold font-display tracking-tight text-white">
                  Study Partner
                </h1>
                <span className="text-[9px] font-bold font-mono bg-indigo-950 border border-indigo-800/40 text-indigo-400 px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                  AI Personal Tutor
                </span>
              </div>
              <p className="text-[10px] text-slate-400">
                Cognitive learning portal & progressive education helper
              </p>
            </div>
          </div>

          {/* Syncing Session Widgets (Interactive Bento Details) */}
          <div className="flex items-center gap-3 md:gap-5 flex-wrap justify-center text-slate-300">
            {/* Active Topic Widget */}
            <div className="bg-slate-950 px-3.5 py-1.5 rounded-xl border border-slate-800 flex items-center gap-2 max-w-xs">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" />
              <div className="min-w-0">
                <span className="text-[8px] font-mono font-bold text-slate-500 uppercase block leading-none mb-0.5">Focus Topic</span>
                <input
                  type="text"
                  value={currentTopic}
                  onChange={(e) => setCurrentTopic(e.target.value)}
                  placeholder="Set learning focus..."
                  className="bg-transparent text-xs text-slate-200 font-semibold focus:outline-none truncate w-32 border-none p-0"
                  title="Click to rename active topic"
                />
              </div>
            </div>

            {/* Quick stats items */}
            <div className="hidden sm:flex items-center gap-1.5 text-slate-400 text-xs">
              <Layers className="w-4 h-4 text-slate-500" />
              <span className="font-semibold text-slate-300 font-mono">{materials.length}</span>
              <span>docs</span>
            </div>

            <div className="hidden sm:flex items-center gap-1.5 text-slate-400 text-xs">
              <Clock className="w-4 h-4 text-slate-500" />
              <span>Streak:</span>
              <span className="font-semibold text-slate-300 font-mono">1 Day</span>
            </div>

            <div className="hidden sm:flex items-center gap-1.5 text-slate-400 text-xs">
              <Trophy className="w-4 h-4 text-slate-500" />
              <span className="font-semibold text-slate-300 font-mono">100</span>
              <span>XP</span>
            </div>
          </div>

        </div>
      </header>

      {/* Main Panel Content with Sidebar Navigation */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-140px)]">
        
        {/* Navigation Control Rail */}
        <div className="lg:col-span-3 flex lg:flex-col gap-2 bg-slate-900/30 p-2.5 rounded-2xl border border-slate-850/60 h-fit">
          <button
            onClick={() => setActiveTab('tutor')}
            className={`flex-1 lg:flex-none flex items-center justify-center lg:justify-start gap-3 px-4 py-3.5 rounded-xl text-sm font-semibold transition-all duration-250 ${
              activeTab === 'tutor' 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-950/20' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <GraduationCap className="w-4.5 h-4.5" />
            <span className="hidden sm:inline lg:inline">AI Tutor Chat</span>
          </button>

          <button
            onClick={() => setActiveTab('materials')}
            className={`flex-1 lg:flex-none flex items-center justify-center lg:justify-start gap-3 px-4 py-3.5 rounded-xl text-sm font-semibold transition-all duration-250 ${
              activeTab === 'materials' 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-950/20' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <FolderOpen className="w-4.5 h-4.5" />
            <span className="hidden sm:inline lg:inline">My Material Hub</span>
            {materials.length > 0 && (
              <span className="hidden lg:inline-block ml-auto text-[10px] font-mono font-bold bg-slate-950 text-indigo-400 px-2 py-0.5 rounded-full border border-slate-800">
                {materials.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('toolkit')}
            className={`flex-1 lg:flex-none flex items-center justify-center lg:justify-start gap-3 px-4 py-3.5 rounded-xl text-sm font-semibold transition-all duration-250 ${
              activeTab === 'toolkit' 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-950/20' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Sparkles className="w-4.5 h-4.5" />
            <span className="hidden sm:inline lg:inline">Interactive Toolkit</span>
          </button>
          
          <div className="hidden lg:block border-t border-slate-850 my-3"></div>

          {/* Core App Information badge */}
          <div className="hidden lg:flex flex-col p-4 bg-slate-950/60 rounded-xl border border-slate-850">
            <div className="flex items-center gap-1.5 text-xs text-slate-300 font-semibold mb-1">
              <Cpu className="w-3.5 h-3.5 text-indigo-400" />
              <span>Adaptive Engine</span>
            </div>
            <p className="text-[10px] text-slate-500 leading-relaxed font-sans">
              Study Partner actively monitors uploaded terminology and structures to personalize explanation levels automatically.
            </p>
          </div>
        </div>

        {/* View Frame */}
        <main className="lg:col-span-9 h-full min-h-[500px]">
          {activeTab === 'tutor' && (
            <TutorChat
              messages={messages}
              setMessages={setMessages}
              activeMaterials={activeMaterials}
              difficulty={difficulty}
              setDifficulty={setDifficulty}
              currentTopic={sessionTopic}
            />
          )}

          {activeTab === 'materials' && (
            <MaterialManager
              materials={materials}
              setMaterials={setMaterials}
              activeMaterialIds={activeMaterialIds}
              setActiveMaterialIds={setActiveMaterialIds}
            />
          )}

          {activeTab === 'toolkit' && (
            <StudyToolkit
              activeMaterials={activeMaterials}
              currentTopic={sessionTopic}
            />
          )}
        </main>

      </div>
    </div>
  );
}
